#!/bin/bash
curPath=`dirname $0`
cd "$curPath"
chmod 766 ./emc_miner_ubuntu
./emc_miner_ubuntu -c=config.yaml