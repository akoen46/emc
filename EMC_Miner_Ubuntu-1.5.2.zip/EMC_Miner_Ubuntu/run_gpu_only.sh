#!/bin/bash
curPath=`dirname $0`
cd "$curPath"
chmod 766 ./emc_miner_ubuntu
echo "Please enter your private key: "
read miner_private
echo "Your input is: $miner_private"
./emc_miner_ubuntu --cpu_enable=false "--miner_private=${miner_private}"